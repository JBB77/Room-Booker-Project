package com.roombooker.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

public class Room {
	
	protected final String roomID;
	protected String roomName;
	protected int capacity;
	protected boolean isNew;
	
	public static Room createNewRoom(String roomID, String roomName, int capacity) {
		Room room = new Room(roomID, roomName, capacity);
		room.isNew = true;
		return room;
	}
	
	protected Room(String roomID, String roomName, int capacity) {
		this.roomID = roomID;
		this.roomName = roomName;
		this.capacity = capacity;
		this.isNew = false;
	}
	
	public String getRoomID() {
		return roomID;
	}
	
	public String getRoomName() {
		return roomName;
	}
	
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	
	public int getCapacity() {
		return capacity;
	}
	
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	private static final class ROOM_RECORD {
		static final String 
			TABLE = "Room",
			PK = "RoomID",
			ORDERBY = "RoomName",
			ROOMID = "RoomID", ROOMID_T = "CHAR(15) NOT NULL",
			ROOMNAME = "RoomName", ROOMNAME_T = "CHAR(25) NOT NULL",
			CAPACITY = "Department", CAPACITY_T = "INT";
	};
	
	protected static void createTable(boolean dropTable, boolean failOK) {
		Statement stmt = RoomBookerModel.getStatement();
        try {
        		if (dropTable) {
        			stmt.executeUpdate(
        				"DROP TABLE " + ROOM_RECORD.TABLE
        			);
        		}
        		String sql =
	    			"CREATE TABLE " + ROOM_RECORD.TABLE + " ("
        			+ ROOM_RECORD.ROOMID + " " + ROOM_RECORD.ROOMID_T + ", "
        			+ ROOM_RECORD.ROOMNAME + " " + ROOM_RECORD.ROOMNAME_T + ", "
        			+ ROOM_RECORD.CAPACITY + " " + ROOM_RECORD.CAPACITY_T + ", "
        			+ "PRIMARY KEY (" + ROOM_RECORD.PK + "))";
            stmt.executeUpdate(sql);
        }
        catch(SQLException e) {
        		if (!failOK) {
        			RoomBookerModel.databaseError(e);
        		}
        }
        RoomBookerModel.closeStatement(stmt);
	}
	
	public static Room roomFromRoomRecord(ResultSet rs) {
		Room room = null;
        try {
			String id = rs.getString(ROOM_RECORD.ROOMID);
			String name = rs.getString(ROOM_RECORD.ROOMNAME);
			int capacity = rs.getInt(ROOM_RECORD.CAPACITY);
			room = new Room(id, name, capacity);
        }
        catch(SQLException e) {
    			RoomBookerModel.databaseError(e);
        }
        return room;
	}
	
	protected static Vector<Room> loadAllRooms() {
		Statement stmt = RoomBookerModel.getStatement();
		Vector<Room> rooms = new Vector<Room>();
        try {
        		String sql =
    	        		"SELECT * FROM " + ROOM_RECORD.TABLE
    	        		+ " ORDER BY " + ROOM_RECORD.ORDERBY;
	        ResultSet rs = stmt.executeQuery(sql);
	        while( rs.next() ) {
	        		Room room = Room.roomFromRoomRecord(rs);
	        		rooms.add(room);
	        }
	        rs.close();
        }
        catch (SQLException e) {
        		RoomBookerModel.databaseError(e);
        }
        RoomBookerModel.closeStatement(stmt);
        return rooms;
	}
	
	protected void save() {
		Statement stmt = RoomBookerModel.getStatement();
		try {
			if (isNew) {
				String sql =
					"INSERT INTO " + ROOM_RECORD.TABLE + " ("
					+ ROOM_RECORD.ROOMID + ", "
					+ ROOM_RECORD.ROOMNAME + ", "
					+ ROOM_RECORD.CAPACITY + ") VALUES ("
					+ "'" + roomID + "', "
					+ "'" + roomName + "', "
					+ capacity + ")";
	            stmt.executeUpdate(sql);
				isNew = false;
			}
			else {
				String sql = 
					"UPDATE " + ROOM_RECORD.TABLE + " SET "
					+ ROOM_RECORD.ROOMNAME + "='" + roomName + "', "
					+ ROOM_RECORD.CAPACITY + "=" + capacity
					+ " WHERE " + ROOM_RECORD.ROOMID + "='" + roomID + "'";
	            stmt.executeUpdate(sql);
			}
        }
        catch (SQLException e) {
        		RoomBookerModel.databaseError(e);
        }
		RoomBookerModel.closeStatement(stmt);
	}
	
	protected void delete() {
		Statement stmt = RoomBookerModel.getStatement();
		try {
			String sql =
				"DELETE FROM " + ROOM_RECORD.TABLE
				+ " WHERE " + ROOM_RECORD.ROOMID + "='" + roomID + "'";
            stmt.executeUpdate(sql);
        }
        catch (SQLException e) {
        		RoomBookerModel.databaseError(e);
        }
		RoomBookerModel.closeStatement(stmt);
	}
}
