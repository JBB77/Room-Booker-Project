package com.roombooker.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Vector;

import javax.swing.JOptionPane;

public class RoomBookerModel {
	private static RoomBookerModel roomBookerModel;
	Connection database;
	private final String[] times = {
			"8:00 AM", "8:30", "9:00", "9:30","10:00",
			"10:30", "11:00", "11:30", "12:00 PM", "12:30",
			"1:00", "1:30", "2:00", "2:30", "3:00",
			"3:30", "4:00", "4:30", "5:00", "5:30",
			"6:00", "6:30", "7:00", "7:30"
		};
	
	private Vector<Room> rooms;
	private HashMap<String, Room> roomMap;
	private String[] roomNames;
	
	private Vector<User> users;
	private HashMap<String, User> userMap;
	private String[] userNames;
	
	private Vector<Reservation> reservations;
	private LocalDateTime rsvDate;

	private Vector<ModelListener> modelListeners = new Vector<ModelListener>();
	
	public static RoomBookerModel getRoomBookerModel() {
		if (roomBookerModel == null) {
			new RoomBookerModel();
		}
		return roomBookerModel;
	}
	
	private RoomBookerModel() {
		roomBookerModel = this;
		initDatabase();
	}
	
	public String[] getTimes() {
		return times;
	}
	
	public Vector<User> getUsers() {
		if (users == null) {
			loadUsers();
		}
		return users;
	}
	
	public String[] getUserNames() {
		if (userNames == null) {
			loadUsers();
		}
		return userNames;
	}
	
	public Vector<Room> getRooms() {
		if (rooms == null) {
			loadRooms();
		}
		return rooms;
	}
	
	public String[] getRoomNames() {
		if (roomNames == null) {
			loadRooms();
		}
		return roomNames;
	}

	public Vector<Reservation> getReservations(LocalDateTime date) {
		if (reservations == null
		|| !stringFromDate(date).equals(stringFromDate(rsvDate))) {
			loadReservations(date);
		}
		return reservations;
	}
	
	public void saveReservation(Reservation rsv) {
		rsv.save();
		clearReservations();
		fireModelChanged();
	}
	
	private void loadReservations(LocalDateTime date) {
		rsvDate = date;
        reservations = Reservation.loadAllReservations(date);
	}

	private void loadUsers() {
        users = User.loadAllUsers();
        	userMap = new HashMap<String, User>();
    		userNames = new String[users.size()];
    		int i = 0;
        	for (User user : users) {
        		userMap.put(user.getUserID(), user);
    			userNames[i++] = user.userName;
        	}
	}
	
	public User addUser(String userID, String userName, String deptId, boolean isStudent) {
		User user;
		if (isStudent) {
			user = Student.createNewSudent(userID, userName, deptId);
		}
		else {
			user = Teacher.createNewTeacher(userID, userName, deptId);
		}
		user.save();
		clearUsers();
		fireModelChanged();
		return user;
	}

	public void updateUser(User user) {
		user.save();
		clearUsers();
		fireModelChanged();
	}
	
	public void deleteUser(User user) {
		user.delete();
		clearUsers();
		Reservation.deleteForUser(user.getUserID());
		clearReservations();
		fireModelChanged();
	}
	
	private void loadRooms() {
        rooms = Room.loadAllRooms();
        	roomMap = new HashMap<String, Room>();
    		roomNames = new String[rooms.size()];
    		int i = 0;
        	for (Room room : rooms) {
        		roomMap.put(room.getRoomID(), room);
    			roomNames[i++] = room.roomName;
        	}
	}
	
	public Room addRoom(String roomID, String roomName, int capacity) {
		Room room = Room.createNewRoom(roomID, roomName, capacity);
		room.save();
		clearRooms();
		fireModelChanged();
		return room;
	}

	public void updateRoom(Room room) {
		room.save();
		clearRooms();
		fireModelChanged();
	}

	public void deleteRoom(Room room) {
		room.delete();
		clearRooms();
		Reservation.deleteForRoom(room.getRoomID());
		clearReservations();
		fireModelChanged();
	}
	
	public void deleteReservation(Reservation rsv) {
		rsv.delete();
		clearReservations();
		fireModelChanged();
	}
	
	public void fireModelChanged() {
		for (ModelListener listener : modelListeners) {
			listener.notifyModelChange();
		}
	}

	public void registerModelListener(ModelListener listener) {
		modelListeners.add(listener);
	}
	
	public void removeModelListener(ModelListener listener) {
		modelListeners.remove(listener);
	}
	
	public void initDatabase() {
		boolean createTables = true;
		boolean dropTables = false;
		boolean failOK = true;
		try
        {
            Class.forName("org.h2.Driver");
            database = DriverManager.getConnection("jdbc:h2:~/RoomBooker", "RoomBooker", "" );
            if (createTables) {
            		User.createTable(dropTables, failOK);
            		Room.createTable(dropTables, failOK);
            		Reservation.createTable(dropTables, failOK);
            }
        }
        catch(SQLException e) {
        		databaseError(e);
        }
		catch(Exception e) {
			databaseError(e);
		}
	}
	
	public void closeDatabase() {
		if (database != null) {
			try {
				database.close();
			} catch (SQLException e) {
				databaseError(e);
			}
			database = null;
		}
	}
	
	protected static void databaseError(Exception e) {
		e.printStackTrace();
		JOptionPane.showMessageDialog(null,
			    e.getMessage(),
			    "Database Error - Program will Exit",
			    JOptionPane.ERROR_MESSAGE);
		System.exit(-1);
	}
	
	public static Statement getStatement() {
		Statement stmt = null;
        try {
	        stmt = getRoomBookerModel().database.createStatement();
        }
        catch (SQLException e) {
        		databaseError(e);
        }
        return stmt;
	}
	
	public static void closeStatement(Statement stmt) {
    		if (stmt != null) {
    			try {
    				stmt.close();
    			}
    	        catch (SQLException e) {
            		databaseError(e);
            }
    		}
	}
	
	private void clearUsers() {
		users = null;
		userMap = null;
		userNames = null;
	}
	
	private void clearRooms() {
		rooms = null;
		roomMap = null;
		roomNames = null;
	}
	
	private void clearReservations() {
		reservations = null;
	}
	
	public User userFromID(String userID) {
		if (userMap == null) {
			loadUsers();
		}
		if (userMap.containsKey(userID)) {
			return userMap.get(userID);
		}
		else {
			return null;
		}
	}
	
	public Room roomFromID(String roomID) {
		if (roomMap == null) {
			loadRooms();
		}
		if (roomMap.containsKey(roomID)) {
			return roomMap.get(roomID);
		}
		else {
			return null;
		}
	}
	
	public LocalDateTime dateFromString(String date) {
		int y = Integer.valueOf(date.substring(0,4));
		int m = Integer.valueOf(date.substring(4,6));
		int d = Integer.valueOf(date.substring(6));
		return LocalDateTime.of(y, m, d, 0, 0);
	}
	
	public String stringFromDate(LocalDateTime date) {
		int y = date.getYear();
		int m = date.getMonthValue();
		int d = date.getDayOfMonth();
		return String.format("%04d%02d%02d", y, m, d);
	}
	
	public int indexForRoom(Room room) {
		if (rooms == null) {
			loadRooms();
		}
		int i = 0;
		for (Room srch : rooms) {
			if (room.getRoomID().equals(srch.getRoomID())) {
				return i;
			}
			i++;
		}
		return -1;
	}
	
	public int indexFromTime(int time) {
		int i = 2*((time/60) - 8);
		if (time%60 > 0) {
			i++;
		}
		return i;
	}
	
	public int timeFromIndex(int timeIndex) {
		int time = ((timeIndex/2)+8)*60;
		if (timeIndex%2 == 1) {
			time += 30;
		}
		return time;
	}
}
