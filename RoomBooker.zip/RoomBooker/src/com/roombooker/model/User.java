package com.roombooker.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

public class User {
	protected final String userID;
	protected String userName;
	protected Boolean isNew;
	
	protected User(String userID, String userName) {
		this.userID = userID;
		this.userName = userName;
		this.isNew = false;
	}
	
	public String getUserID() {
		return userID;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}

	private static final class USER_RECORD {
		static final String 
			TABLE = "Users",
			PK = "UserID",
			ORDERBY = "UserName",
			USERID = "UserID", USERID_T = "CHAR(15) NOT NULL",
			USERTYPE = "UserType", USERTYPE_T = "CHAR(1) NOT NULL",
			USERNAME = "UserName", USERNAME_T = "CHAR(25) NOT NULL",
			STUDENTID = "StudentID", STUDENTID_T = "CHAR(15)",
			DEPARTMENT = "Department", DEPARTMENT_T = "CHAR(25)",
			TYPE_STUDENT = "S", TYPE_TEACHER = "T";
	};
	
	protected static void createTable(boolean dropTable, boolean failOK) {
		Statement stmt = RoomBookerModel.getStatement();
        try {
        		if (dropTable) {
        			stmt.executeUpdate(
        				"DROP TABLE " + USER_RECORD.TABLE
        			);
        		}
        		String sql =
	    			"CREATE TABLE " + USER_RECORD.TABLE + " ("
        			+ USER_RECORD.USERID + " " + USER_RECORD.USERID_T + ", "
        			+ USER_RECORD.USERTYPE + " " + USER_RECORD.USERTYPE_T + ", "
        			+ USER_RECORD.USERNAME + " " + USER_RECORD.USERNAME_T + ", "
        			+ USER_RECORD.STUDENTID + " " + USER_RECORD.STUDENTID_T + ", "
        			+ USER_RECORD.DEPARTMENT + " " + USER_RECORD.DEPARTMENT_T + ", "
        			+ "PRIMARY KEY (" + USER_RECORD.PK + "))";
            stmt.executeUpdate(sql);
        }
        catch(SQLException e) {
        		if (!failOK) {
        			RoomBookerModel.databaseError(e);
        		}
        }
        RoomBookerModel.closeStatement(stmt);
	}
	
	protected static User userFromUserRecord(ResultSet rs) {
		User user = null;
        try {
			String id = rs.getString(USER_RECORD.USERID);
			String name = rs.getString(USER_RECORD.USERNAME);
			String type = rs.getString(USER_RECORD.USERTYPE);
			if (type.equals(USER_RECORD.TYPE_STUDENT)) {
				String studentId = rs.getString(USER_RECORD.STUDENTID);
				user = new Student(id, name, studentId);
			}
			else if (type.equals(USER_RECORD.TYPE_TEACHER)) {
				String department = rs.getString(USER_RECORD.DEPARTMENT);
				user = new Teacher(id, name, department);
			}
			else {
				// error invalid
			}
        }
        catch(SQLException e) {
    			RoomBookerModel.databaseError(e);
        }
        return user;
	}
	
	protected static Vector<User> loadAllUsers() {
		Statement stmt = RoomBookerModel.getStatement();
		Vector<User> users = new Vector<User>();
        try {
        		String sql =
    	        		"SELECT * FROM " + USER_RECORD.TABLE
    	        		+ " ORDER BY " + USER_RECORD.ORDERBY;
	        ResultSet rs = stmt.executeQuery(sql);
	        while( rs.next() ) {
	        		User user = User.userFromUserRecord(rs);
	        		users.add(user);
	        }
	        rs.close();
        }
        catch (SQLException e) {
        		RoomBookerModel.databaseError(e);
        }
        RoomBookerModel.closeStatement(stmt);
        return users;
	}
	
	protected void save() {
		Statement stmt = RoomBookerModel.getStatement();
		try {
			if (isNew) {
				String sql =
					"INSERT INTO " + USER_RECORD.TABLE + " ("
					+ USER_RECORD.USERID + ", "
					+ USER_RECORD.USERNAME + ", "
					+ USER_RECORD.USERTYPE + ", "
					+ USER_RECORD.STUDENTID + ", "
					+ USER_RECORD.DEPARTMENT + ") VALUES ("
					+ "'" + userID + "', "
					+ "'" + userName + "', "
					+ ((this instanceof Student) 
					?	"'" + USER_RECORD.TYPE_STUDENT + "', "
						+ "'" + ((Student)this).studentID + "', "
						+ "'')" 
					: 	"'" + USER_RECORD.TYPE_TEACHER + "', "
						+ "'', '" + ((Teacher)this).department + "')");
	            stmt.executeUpdate(sql);
				isNew = false;
			}
			else {
				String sql = 
					"UPDATE " + USER_RECORD.TABLE + " SET "
					+ USER_RECORD.USERNAME + "='" + userName + "', "
					+ ((this instanceof Student) 
					?	USER_RECORD.STUDENTID + "='" 
						+ ((Student)this).studentID + "', "
						+ USER_RECORD.DEPARTMENT + "=''"
					:	USER_RECORD.STUDENTID + "='', " 
						+ USER_RECORD.DEPARTMENT +"='"
						+ ((Teacher)this).department + "' ")
					+ "WHERE " + USER_RECORD.USERID + "='" + userID + "'";
	            stmt.executeUpdate(sql);
			}
        }
        catch (SQLException e) {
        		RoomBookerModel.databaseError(e);
        }
		RoomBookerModel.closeStatement(stmt);
	}
	
	protected void delete() {
		Statement stmt = RoomBookerModel.getStatement();
		try {
			String sql =
				"DELETE FROM " + USER_RECORD.TABLE
				+ " WHERE " + USER_RECORD.USERID + "='" + userID + "'";
            stmt.executeUpdate(sql);
        }
        catch (SQLException e) {
        		RoomBookerModel.databaseError(e);
        }
		RoomBookerModel.closeStatement(stmt);
	}
}
