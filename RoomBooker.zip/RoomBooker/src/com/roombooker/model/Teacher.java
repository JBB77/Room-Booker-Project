package com.roombooker.model;

public class Teacher extends User {
	
	protected String department;
	
	public static Teacher createNewTeacher(String userID, String userName, String department) {
		Teacher teacher = new Teacher(userID, userName, department);
		teacher.isNew = true;
		return teacher;
	}

	protected Teacher(String userID, String userName, String department) {
		super(userID, userName);
		this.department = department;
	}
	
	public String getDepartment() {
		return department;
	}
	
	public void setDepartment(String department) {
		this.department = department;
	}	
}
