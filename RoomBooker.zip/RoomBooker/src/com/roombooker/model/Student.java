package com.roombooker.model;

public class Student extends User {
	
	protected String studentID;
	
	public static Student createNewSudent(String userID, String userName, String studentID) {
		Student student = new Student(userID, userName, studentID);
		student.isNew = true;
		return student;
	}
	
	protected Student(String userID, String userName, String studentID) {
		super(userID, userName);
		this.studentID = studentID;
	}
	
	public String getStudentID() {
		return studentID;
	}
	
	public void setStudentID(String studentID) {
		this.studentID = studentID;
	}
}
