package com.roombooker.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.Vector;

public class Reservation {
	protected final User user;
	protected final Room room;
	protected final int people;
	protected final LocalDateTime date;
	protected final int timeStart;
	protected final int timeEnd;
	protected boolean isNew;
	
	public static Reservation createNewReservation(
			User user, Room room, int people, 
			LocalDateTime date, int timeStart, int timeEnd) {
		Reservation rsv = 
				new Reservation(user, room, people, date, timeStart, timeEnd);
		rsv.isNew = true;
		return rsv;
	}
	
	protected Reservation(User user, Room room, int people, 
			LocalDateTime date, int timeStart, int timeEnd) {
		this.user = user;
		this.room = room;
		this.people = people;
		this.date = date;
		this.timeStart = timeStart;
		this.timeEnd = timeEnd;
		this.isNew = false;
	}
	
	public User getUser() {
		return user;
	}
	public Room getRoom() {
		return room;
	}
	public int getPeople() {
		return people;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public int getTimeStart() {
		return timeStart;
	}
	public int getDuration() {
		return timeEnd-timeStart;
	}
	public int getTimeEnd() {
		return timeEnd;
	}
	
	private static final class RSV_RECORD {
		static final String 
			TABLE = "Reservation",
			USERID = "UserID",	USERID_T = "CHAR(15) NOT NULL",
			ROOMID = "RoomID",	ROOMID_T = "CHAR(15) NOT NULL",
			DATE = "Date",		DATE_T = "CHAR(8) NOT NULL",
			TIMESTART = "TimeStart", TIMESTART_T = "INT NOT NULL",
			TIMEEND = "TimeEnd", 	TIMEEND_T = "INT NOT NULL",
			PEOPLE = "People", 	PEOPLE_T = "INT";
	};
	
	protected static void createTable(boolean dropTable, boolean failOK) {
		Statement stmt = RoomBookerModel.getStatement();
        try {
        		if (dropTable) {
        			stmt.executeUpdate(
        				"DROP TABLE " + RSV_RECORD.TABLE
        			);
        		}
        		String sql =
	    			"CREATE TABLE " + RSV_RECORD.TABLE + " ("
        			+ RSV_RECORD.USERID + " " + RSV_RECORD.USERID_T + ", "
        			+ RSV_RECORD.ROOMID + " " + RSV_RECORD.ROOMID_T + ", "
        			+ RSV_RECORD.DATE + " " + RSV_RECORD.DATE_T + ", "
        			+ RSV_RECORD.TIMESTART + " " + RSV_RECORD.TIMESTART_T + ", "
        			+ RSV_RECORD.TIMEEND + " " + RSV_RECORD.TIMEEND_T + ", "
        			+ RSV_RECORD.PEOPLE + " " + RSV_RECORD.PEOPLE_T + ")";
            stmt.executeUpdate(sql);
        }
        catch(SQLException e) {
        		if (!failOK) {
        			RoomBookerModel.databaseError(e);
        		}
        }
        RoomBookerModel.closeStatement(stmt);
	}
	
	public static Reservation rsvFromRsvRecord(ResultSet rs) {
		Reservation rsv = null;
        try {
        		RoomBookerModel model = RoomBookerModel.getRoomBookerModel();
        		String userID = rs.getString(RSV_RECORD.USERID);
			String roomID = rs.getString(RSV_RECORD.ROOMID);
			String date = rs.getString(RSV_RECORD.DATE);
			int timeStart = rs.getInt(RSV_RECORD.TIMESTART);
			int timeEnd = rs.getInt(RSV_RECORD.TIMEEND);
			int people = rs.getInt(RSV_RECORD.PEOPLE);
			rsv = new Reservation(
				model.userFromID(userID),
				model.roomFromID(roomID),
				people,
				model.dateFromString(date),
				timeStart,
				timeEnd);
        }
        catch(SQLException e) {
    			RoomBookerModel.databaseError(e);
        }
        return rsv;
	}
	
	protected static Vector<Reservation> loadAllReservations(LocalDateTime date) {
		Statement stmt = RoomBookerModel.getStatement();
		Vector<Reservation> rsvs = new Vector<Reservation>();
		RoomBookerModel model = RoomBookerModel.getRoomBookerModel();
		String dateStr = model.stringFromDate(date);
        try {
        		String sql =
    	        		"SELECT * FROM " + RSV_RECORD.TABLE
    	        		+ " WHERE " + RSV_RECORD.DATE + "='"
    	        		+ dateStr + "'";
	        ResultSet rs = stmt.executeQuery(sql);
	        while (rs.next()) {
	        		Reservation rsv = Reservation.rsvFromRsvRecord(rs);
	        		rsvs.add(rsv);
	        }
	        rs.close();
        }
        catch (SQLException e) {
        		RoomBookerModel.databaseError(e);
        }
        return rsvs;
	}
	
	protected void save() {
		Statement stmt = RoomBookerModel.getStatement();
		try {
			RoomBookerModel model = RoomBookerModel.getRoomBookerModel();
			if (isNew) {
				String sql =
					"INSERT INTO " + RSV_RECORD.TABLE + " ("
					+ RSV_RECORD.USERID + ", "
					+ RSV_RECORD.ROOMID + ", "
					+ RSV_RECORD.DATE + ", "
					+ RSV_RECORD.TIMESTART + ", "
					+ RSV_RECORD.TIMEEND + ", "
					+ RSV_RECORD.PEOPLE + ") VALUES ("
					+ "'" + user.getUserID() + "', "
					+ "'" + room.getRoomID() + "', "
					+ "'" + model.stringFromDate(date) + "', "
					+ timeStart + ", " 
					+ timeEnd + ", "
					+ people + ")";
	            stmt.executeUpdate(sql);
				isNew = false;
			}
			else {
				// no updating reservations
				// they are saved/deleted only
			}
        }
        catch (SQLException e) {
        		RoomBookerModel.databaseError(e);
        }
		RoomBookerModel.closeStatement(stmt);
	}
	
	protected void delete() {
		Statement stmt = RoomBookerModel.getStatement();
		try {
			RoomBookerModel model = RoomBookerModel.getRoomBookerModel();
			String sql =
				"DELETE FROM " + RSV_RECORD.TABLE + " WHERE "
				+ RSV_RECORD.USERID + "='" + user.getUserID() + "' AND "
				+ RSV_RECORD.ROOMID + "='" + room.getRoomID() + "' AND "
				+ RSV_RECORD.DATE + "='" + model.stringFromDate(date) + "' AND "
				+ RSV_RECORD.TIMESTART + "=" + timeStart;
            stmt.executeUpdate(sql);
        }
        catch (SQLException e) {
        		RoomBookerModel.databaseError(e);
        }
		RoomBookerModel.closeStatement(stmt);
	}
	
	protected static void deleteForUser(String userID) {
		Statement stmt = RoomBookerModel.getStatement();
		try {
			String sql =
				"DELETE FROM " + RSV_RECORD.TABLE + " WHERE "
				+ RSV_RECORD.USERID + "='" + userID + "'";
            stmt.executeUpdate(sql);
        }
        catch (SQLException e) {
        		RoomBookerModel.databaseError(e);
        }
		RoomBookerModel.closeStatement(stmt);
	}
	
	protected static void deleteForRoom(String roomID) {
		Statement stmt = RoomBookerModel.getStatement();
		try {
			String sql =
				"DELETE FROM " + RSV_RECORD.TABLE + " WHERE "
				+ RSV_RECORD.ROOMID + "='" + roomID + "'";
            stmt.executeUpdate(sql);
        }
        catch (SQLException e) {
        		RoomBookerModel.databaseError(e);
        }
		RoomBookerModel.closeStatement(stmt);
	}
	
	public static int totalReservedForDay(String userID, LocalDateTime date) {
		RoomBookerModel model = RoomBookerModel.getRoomBookerModel();
		Statement stmt = RoomBookerModel.getStatement();
		int totalMinutes = 0;
        try {
        		String sql =
    	        		"SELECT SUM(" 
    	        		+ RSV_RECORD.TIMEEND + "-"
        			+ RSV_RECORD.TIMESTART + ")"
    	        		+ " AS totalMinutes FROM " 
    	        		+ RSV_RECORD.TABLE + " WHERE "
    	        		+ RSV_RECORD.USERID + "='" + userID + "' AND "
    	        		+ RSV_RECORD.DATE + "='" + model.stringFromDate(date) + "'";
    	        ResultSet rs = stmt.executeQuery(sql);
        		rs.next();
        		totalMinutes = rs.getInt("totalMinutes");
        		rs.close();
        }
        catch (SQLException e) {
        		RoomBookerModel.databaseError(e);
        }
        RoomBookerModel.closeStatement(stmt);
        return totalMinutes;
	}
	
	public boolean isRoomAlreadyBooked() {
		RoomBookerModel model = RoomBookerModel.getRoomBookerModel();
		Statement stmt = RoomBookerModel.getStatement();
		int count = 0;
        try {
        		String sql =
    	        		"SELECT COUNT(*) AS rowcount FROM " 
    	        		+ RSV_RECORD.TABLE + " WHERE "
    	        		+ RSV_RECORD.ROOMID + "='" + room.getRoomID() + "' AND "
    	        		+ RSV_RECORD.DATE + "='" + model.stringFromDate(date) + "' AND (("
    	        		+ timeStart + ">=" + RSV_RECORD.TIMESTART + " AND "
    	        		+ timeStart + "<" + RSV_RECORD.TIMEEND + ") OR ("
    	        		+ timeEnd + ">" + RSV_RECORD.TIMESTART + " AND "
    	        		+ timeEnd + "<" + RSV_RECORD.TIMEEND + ") OR ("
    	        		+ timeStart + "<=" + RSV_RECORD.TIMESTART + " AND "
    	        		+ timeEnd + ">=" + RSV_RECORD.TIMEEND + "))";
    	        ResultSet rs = stmt.executeQuery(sql);
        		rs.next();
        		count = rs.getInt("rowcount");
        		rs.close();
        }
        catch (SQLException e) {
        		RoomBookerModel.databaseError(e);
        }
        RoomBookerModel.closeStatement(stmt);
        return count > 0;
	}
	
	public boolean isUserAlreadyBooked() {
		RoomBookerModel model = RoomBookerModel.getRoomBookerModel();
		Statement stmt = RoomBookerModel.getStatement();
		int count = 0;
        try {
        		String sql =
    	        		"SELECT COUNT(*) AS rowcount FROM " 
    	        		+ RSV_RECORD.TABLE + " WHERE "
    	        		+ RSV_RECORD.USERID + "='" + user.getUserID() + "' AND "
    	        		+ RSV_RECORD.DATE + "='" + model.stringFromDate(date) + "' AND (("
    	        		+ timeStart + ">=" + RSV_RECORD.TIMESTART + " AND "
    	        		+ timeStart + "<" + RSV_RECORD.TIMEEND + ") OR ("
    	        		+ timeEnd + ">" + RSV_RECORD.TIMESTART + " AND "
    	        		+ timeEnd + "<" + RSV_RECORD.TIMEEND + ") OR ("
    	        		+ timeStart + "<=" + RSV_RECORD.TIMESTART + " AND "
    	        		+ timeEnd + ">=" + RSV_RECORD.TIMEEND + "))";
    	        ResultSet rs = stmt.executeQuery(sql);
        		rs.next();
        		count = rs.getInt("rowcount");
        		rs.close();
        }
        catch (SQLException e) {
        		RoomBookerModel.databaseError(e);
        }
        RoomBookerModel.closeStatement(stmt);
        return count > 0;
	}
}
