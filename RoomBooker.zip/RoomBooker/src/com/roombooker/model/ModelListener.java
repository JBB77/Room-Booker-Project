package com.roombooker.model;

public interface ModelListener {
	public void notifyModelChange();
}
