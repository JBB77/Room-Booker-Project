package com.roombooker.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Rectangle;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.roombooker.RoomBookerApp;
import com.roombooker.controller.ManageUsersViewController;
import java.awt.Dimension;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import java.awt.GridLayout;
import java.awt.Font;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.AbstractListModel;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.border.EtchedBorder;
import javax.swing.ListSelectionModel;

public class ManageUsersView extends JDialog {

	private final ManageUsersViewController controller;
	private final JPanel userListPanel = new JPanel();
	private String[] userNames;
	private final JList userList;
	private final JPanel userButtons;
	private final JButton cancelButton;
	private final JButton saveButton;
	private final JButton addUserButton;
	private final JButton deleteUserButton;
	private final JPanel editButtons;
	private final JButton editUserButton;
	private final JLabel titleLabel;
	private final JTextField userID;
	private final JTextField userName;
	private final JLabel userNameLabel;
	private final JLabel userIDLabel;
	private final JTextField deptId;
	private final JLabel deptIdLabel;
	private boolean isStudent;
	private boolean editMode = false;
	private boolean addMode = false;
	
	/**
	 * Create the dialog.
	 */
	public ManageUsersView(ManageUsersViewController controller) {
		this.controller = controller;
		
		setBounds(100, 100, 700, 450);
		resize();
		
		getContentPane().setLayout(new BorderLayout());
		{
			JPanel titlePanel = new JPanel();
			titlePanel.setBackground(Color.BLUE);
			getContentPane().add(titlePanel, BorderLayout.NORTH);
			titlePanel.setLayout(new GridLayout(0, 1, 0, 0));
			{
				JLabel lblNewLabel = new JLabel("Manage Users");
				lblNewLabel.setForeground(Color.WHITE);
				lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
				lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD, 24));
				titlePanel.add(lblNewLabel);
			}
		}
		userListPanel.setPreferredSize(new Dimension(250, 10));
		userListPanel.setMinimumSize(new Dimension(250, 10));
		userListPanel.setMaximumSize(new Dimension(250, 32767));
		userListPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(userListPanel, BorderLayout.WEST);
		userListPanel.setLayout(new BorderLayout(0, 0));
		{
			userList = new JList();
			userList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			userList.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
			userList.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
			userList.addListSelectionListener(new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent e) {
					controller.selectUser(userList.getSelectedIndex());
				}
			});
			updateUserList();
			userListPanel.add(userList, BorderLayout.CENTER);
		}
		{
			userButtons = new JPanel();
			userButtons.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
			userListPanel.add(userButtons, BorderLayout.SOUTH);
			userButtons.setLayout(new GridLayout(1, 0, 0, 0));
			{
				addUserButton = new JButton("+");
				addUserButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Object[] options = {"Add a student",
						                    "Add a teacher",
						                    "Cancel"};
						int n = JOptionPane.showOptionDialog(null,
						    "Select new user type",
						    "Add New User",
						    JOptionPane.YES_NO_CANCEL_OPTION,
						    JOptionPane.QUESTION_MESSAGE,
						    null,
						    options,
						    options[2]);	
						if (n == 0 || n == 1) {
							enterAddMode(n==0);
						}
					}
				});
				userButtons.add(addUserButton);
			}
			{
				deleteUserButton = new JButton("-");
				deleteUserButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						int index = userList.getSelectedIndex();
						if (index >= 0) {
							int n = JOptionPane.showConfirmDialog(
								    null,
								    "Do you want to delete user " + userNames[index] + "?",
								    "Confirm Deletion",
								    JOptionPane.YES_NO_OPTION);
							if (n == JOptionPane.YES_OPTION) {
								controller.deleteUser(index);
								updateUserList();
								if (userNames.length > 0) {
									userList.setSelectedIndex(0);
									controller.selectUser(0);
								}
								else {
									userList.clearSelection();
									controller.selectUser(-1);
								}
							}
						}
					}
				});
				userButtons.add(deleteUserButton);
			}
			{
				editUserButton = new JButton("Edit");
				editUserButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if (userNames.length > 0 && userList.getSelectedIndex() >= 0) {
							enterEditMode();
						}
					}
				});
				userButtons.add(editUserButton);
			}
		}
		{
			JPanel userFormPanel = new JPanel();
			userFormPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
			getContentPane().add(userFormPanel, BorderLayout.CENTER);
			userFormPanel.setLayout(new BorderLayout(0, 0));
			{
				JPanel userFields = new JPanel();
				userFields.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
				userFormPanel.add(userFields, BorderLayout.CENTER);
				userFields.setLayout(new GridLayout(10, 4, 0, 0));
				{
					titleLabel = new JLabel("Student Data");
					userFields.add(titleLabel);
					titleLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
				}
				{
					userIDLabel = new JLabel("User ID:");
					userFields.add(userIDLabel);
				}
				{
					userID = new JTextField();
					userID.setEnabled(false);
					userFields.add(userID);
					userID.setColumns(10);
				}
				userIDLabel.setLabelFor(userID);
				{
					userNameLabel = new JLabel("User Name:");
					userFields.add(userNameLabel);
				}
				{
					userName = new JTextField();
					userName.setEnabled(false);
					userFields.add(userName);
					userName.setColumns(10);
				}
				userNameLabel.setLabelFor(userName);
				{
					deptIdLabel = new JLabel("Student ID:");
					userFields.add(deptIdLabel);
				}
				{
					deptId = new JTextField();
					deptId.setEnabled(false);
					userFields.add(deptId);
					deptId.setColumns(10);
				}
				deptIdLabel.setLabelFor(deptId);
			}
			{
				editButtons = new JPanel();
				editButtons.setVisible(false);
				editButtons.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
				userFormPanel.add(editButtons, BorderLayout.SOUTH);
				{
					cancelButton = new JButton("Cancel");
					cancelButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							exitEditMode();
						}
					});
					cancelButton.setEnabled(false);
					editButtons.add(cancelButton);
				}
				{
					saveButton = new JButton("Save");
					saveButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							int index;
							String id = userID.getText();
							String name = userName.getText();
							String di = deptId.getText();
							if (addMode) {
								index = controller.addUser(id, name, di, isStudent);
							}
							else {
								index = userList.getSelectedIndex();
								controller.updateUser(index, name, di);
							}
							exitEditMode();
							updateUserList();
							userList.setSelectedIndex(index);
							controller.selectUser(index);
						}
					});
					saveButton.setEnabled(false);
					editButtons.add(saveButton);
				}
			}
		}
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setVisible(true);
	}

	public void resize() {
		if (RoomBookerApp.isRunning()) {
			Rectangle b1 = RoomBookerApp.getApp().getMainWindow().getBounds();
			Rectangle b2 = getBounds();
			b2.x = (b1.width - b2.width)/2;
			b2.y = (b1.height - b2.height)/2;
			setBounds(b2);
		}
	}
	
	public void setUserFields(String userID, String userName, String deptId, boolean isStudent) {
		this.userID.setText(userID);
		this.userName.setText(userName);
		this.deptId.setText(deptId);
		this.isStudent = isStudent;
		if (isStudent) {
			titleLabel.setText("Student Data");
			deptIdLabel.setText("Student ID:");
		}
		else {
			titleLabel.setText("Teacher Data");
			deptIdLabel.setText("Department:");
		}
	}
	
	public void enterEditMode() {
		editMode = true;
		addUserButton.setEnabled(false);
		editUserButton.setEnabled(false);
		deleteUserButton.setEnabled(false);
		userList.setEnabled(false);
		userID.setEnabled(false);
		userName.setEnabled(true);
		deptId.setEnabled(true);
		cancelButton.setEnabled(true);
		saveButton.setEnabled(true);
		editButtons.setVisible(true);
		userName.grabFocus();
	}
	
	public void exitEditMode() {
		addUserButton.setEnabled(true);
		editUserButton.setEnabled(true);
		deleteUserButton.setEnabled(true);
		userList.setEnabled(true);
		userID.setEnabled(false);
		userName.setEnabled(false);
		deptId.setEnabled(false);
		cancelButton.setEnabled(false);
		saveButton.setEnabled(false);
		editButtons.setVisible(false);
		editMode = false;
		addMode = false;
	}
	
	public void enterAddMode(boolean addStudent) {
		userList.clearSelection();
		setUserFields("", "", "", addStudent);
		addMode = true;
		enterEditMode();
		userID.setEnabled(true);
		userID.grabFocus();
	}
	
	void updateUserList() {
		userNames = controller.getModel().getUserNames();
		userList.setModel(new AbstractListModel() {
			String[] values = userNames;
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});

	}
}
