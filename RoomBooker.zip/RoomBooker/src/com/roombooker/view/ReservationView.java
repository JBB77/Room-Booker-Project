package com.roombooker.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JToolBar;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.GridLayout;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.FlowLayout;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.BoxLayout;
import java.awt.CardLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;

import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.roombooker.controller.CalendarViewController;
import com.roombooker.controller.ReservationViewController;

import net.miginfocom.swing.MigLayout;
import javax.swing.border.EtchedBorder;
import java.awt.Component;
import javax.swing.Box;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.DefaultComboBoxModel;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.stream.Stream;

import javax.swing.JSeparator;
import javax.swing.JScrollPane;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ReservationView extends JPanel {

	private final ReservationViewController controller;
	private final JComboBox selectUser;
	private final JComboBox selectPeople;
	private final CalendarView calendarView;
	private final JComboBox selectRoom;
	private final JComboBox selectTime;
	private final JComboBox selectDuration;
	private String users[];
	private String rooms[];
	
	public ReservationView(ReservationViewController controller) {
		this.controller = controller;
		
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setBackground(new Color(128, 0, 128));
		setBorder(new EmptyBorder(15, 15, 15, 15));
		setPreferredSize(new Dimension(300, 600));
		setMinimumSize(new Dimension(300, 10));
		setMaximumSize(new Dimension(300, 32767));
		
		JLabel title = new JLabel("Make a Reservation");
		title.setAlignmentX(Component.CENTER_ALIGNMENT);
		title.setForeground(new Color(255, 255, 255));
		title.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		title.setHorizontalAlignment(SwingConstants.CENTER);
		add(title);
		
		JSeparator s1 = new JSeparator();
		s1.setMaximumSize(new Dimension(32767, 15));
		add(s1);
		
		selectUser = new JComboBox();
		selectUser.setMaximumSize(new Dimension(32767, 40));
		selectUser.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		add(selectUser);
		
		selectPeople = new JComboBox();
		selectPeople.setModel(new DefaultComboBoxModel(new String[] {"Number of people...", "1", "2", "3", "4", "5", "6", "7", "8"}));
		selectPeople.setMaximumSize(new Dimension(32767, 40));
		selectPeople.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		add(selectPeople);
		
		selectRoom = new JComboBox();
		selectRoom.setMaximumSize(new Dimension(32767, 40));
		selectRoom.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		selectRoom.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					controller.onScheduleChange(
							selectRoom.getSelectedIndex(),
							selectTime.getSelectedIndex(),
							selectDuration.getSelectedIndex());
			    }
			}
		});
		add(selectRoom);
		
		JSeparator s2 = new JSeparator();
		s2.setMaximumSize(new Dimension(32767, 20));
		add(s2);
		
		calendarView = CalendarViewController.createCalendarView(this);
		add(calendarView);
		
		Component strut1 = Box.createVerticalStrut(20);
		strut1.setMinimumSize(new Dimension(0, 10));
		strut1.setMaximumSize(new Dimension(32767, 10));
		add(strut1);
		
		selectTime = new JComboBox();
		selectTime.setMaximumSize(new Dimension(32767, 40));
		selectTime.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		selectTime.setModel(new DefaultComboBoxModel(new String[] {"Select Time...", "8:00 AM", "8:30", "9:00", "9:30", "10:00", "10:30", "11:00", "11:30", "12:00 PM", "12:30", "1:00", "1:30", "2:00", "2:30", "3:00", "3:30", "4:00", "4:30", "5:00", "5:30", "6:00", "6:30", "7:00", "7:30"}));
		selectTime.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					controller.onScheduleChange(
							selectRoom.getSelectedIndex(),
							selectTime.getSelectedIndex(),
							selectDuration.getSelectedIndex());
			    }
			}
		});
		add(selectTime);
		
		selectDuration = new JComboBox();
		selectDuration.setMaximumSize(new Dimension(32767, 40));
		selectDuration.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		selectDuration.setModel(new DefaultComboBoxModel(new String[] {"Select Duration...", "30 Minutes", "1 Hour", "1 Hour 30 Minutes", "2 Hours"}));
		selectDuration.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					controller.onScheduleChange(
							selectRoom.getSelectedIndex(),
							selectTime.getSelectedIndex(),
							selectDuration.getSelectedIndex());
			    }
			}
		});
		add(selectDuration);
		
		Component strut2 = Box.createVerticalStrut(20);
		strut2.setMinimumSize(new Dimension(0, 10));
		strut2.setMaximumSize(new Dimension(32767, 10));
		add(strut2);
		
		JSeparator s3 = new JSeparator();
		s3.setMaximumSize(new Dimension(32767, 20));
		add(s3);
		
		JButton confirmReservationButton = new JButton("Confirm Reservation");
		confirmReservationButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.confirmReservation(
						selectUser.getSelectedIndex(),
						selectPeople.getSelectedIndex(),
						calendarView,
						selectRoom.getSelectedIndex(),
						selectTime.getSelectedIndex(),
						selectDuration.getSelectedIndex()
						);
			}
		});
		confirmReservationButton.setPreferredSize(new Dimension(32767, 40));
		confirmReservationButton.setMaximumSize(new Dimension(32767, 40));
		confirmReservationButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		confirmReservationButton.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		add(confirmReservationButton);
		updateLists();
	}
	
	public void initialize() {
		selectUser.setSelectedIndex(0);
		selectPeople.setSelectedIndex(0);
		selectRoom.setSelectedIndex(0);
		selectTime.setSelectedIndex(0);
		selectDuration.setSelectedIndex(0);
	}
	
	public ReservationViewController getController() {
		return controller;
	}
	
	public CalendarView getCalendarView() {
		return calendarView;
	}
	
	public JComboBox getSelectRoomControl() {
		return selectRoom;
	}
	
	public JComboBox getSelectTimeControl() {
		return selectTime;
	}
	
	public JComboBox getSelectDurationControl() {
		return selectDuration;
	}
	public void updateLists() {
		String[] tmpUsers = {"Select a user..."};
		users = Stream.of(tmpUsers, controller.getModel().getUserNames())
				.flatMap(Stream::of)
                .toArray(String[]::new);
		selectUser.setModel(new DefaultComboBoxModel(users));
		
		String[] tmpRooms = {"Select a room..."};
		rooms = Stream.of(tmpRooms, controller.getModel().getRoomNames())
				.flatMap(Stream::of)
                .toArray(String[]::new);
		selectRoom.setModel(new DefaultComboBoxModel(rooms));
	}
	
}
