package com.roombooker.view;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.roombooker.controller.ScheduleViewController;
import com.roombooker.model.Reservation;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;

public class ScheduleCell extends JPanel {

	private final ScheduleView scheduleView;
	private final int rowHeight = 50;
	private final int colWidth = 75;
	private final Color freeCellBG = new Color(0, 255, 0);
	private final Color selectedCellBG = new Color(255, 0, 0);
	private final Color bookedCellBG = new Color(80, 80, 80);
	private int row;
	private int col;
	private int span;
	private boolean selected = false;
	private boolean booked = false;
	private Reservation bookedReservation;
	
	/**
	 * Create the panel.
	 */
	public ScheduleCell(ScheduleView scheduleView, int row, int col, int span) {
		this.scheduleView = scheduleView;
		this.row = row;
		this.col = col;
		this.span = span;
		setBorder(new EmptyBorder(2, 2, 2, 2));
		setLayout(new BorderLayout(0, 0));
		
		ScheduleViewController ctrlr = scheduleView.getController();
		ScheduleCell cell = this;
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ctrlr.clickScheduleCell(cell);
			}
		});
		paintCell();
	}
	
	public int getRow() {
		return row;
	}
	
	public int getCol() {
		return col;
	}
	
	public boolean isSelected() {
		return selected;
	}
	
	public boolean isBooked() {
		return booked;
	}
	
	public void setSelected(boolean selected) {
		if (!this.booked) {
			this.selected = selected;
			removeAll();
			if (selected) {
				JLabel l1 = new JLabel("< ");
				l1.setFont(new Font("Lucida Grande", Font.BOLD, 24));
				l1.setForeground(new Color(255,255,255));
				add(l1,BorderLayout.WEST);
				
				JLabel l3 = new JLabel(" >");
				l3.setFont(new Font("Lucida Grande", Font.BOLD, 24));
				l3.setForeground(new Color(255,255,255));
				add(l3, BorderLayout.EAST);
			}
			paintCell();
		}
	}
	
	public void setBooked(Reservation rsv) {
		selected = false;
		booked = true;
		bookedReservation = rsv;
		
		JLabel deleteX = new JLabel("[X] ");
		deleteX.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		deleteX.setForeground(new Color(255, 0, 0));
		deleteX.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int n = JOptionPane.showConfirmDialog(
					    null,
					    "Do you want to delete this reservation?",
					    "Confirm Deletion",
					    JOptionPane.YES_NO_OPTION);
				if (n == JOptionPane.YES_OPTION) {
					scheduleView.getController().getModel()
						.deleteReservation(bookedReservation);
				}
			}
		});
		add(deleteX,BorderLayout.WEST);
		
		JLabel nameLabel = new JLabel(
			"<html>" + rsv.getUser().getUserName() 
			+ " (" + rsv.getPeople() + ")</html>");
		nameLabel.setBackground(new Color(80, 80, 80));
		nameLabel.setForeground(new Color(255, 255, 255));
		nameLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		nameLabel.setAlignmentY(CENTER_ALIGNMENT);
		
		add(nameLabel, BorderLayout.CENTER);
		
		paintCell();
	}
	
	public int getSpan() {
		return span;
	}
	
	public void setSpan(int span) {
		this.span = span;
		paintCell();
	}
	
	public void setCol(int col) {
		this.col = col;
	}
	
	public void paintCell() {
		if (booked) {
			setBackground(bookedCellBG);
		}
		else {
			if (selected) {
				setBackground(selectedCellBG);
			}
			else {
				setBackground(freeCellBG);
			}
		}
		setBounds((col*colWidth) + 1, (row*rowHeight)+1, 
				(span*colWidth)-2, rowHeight-2);
	}
}
