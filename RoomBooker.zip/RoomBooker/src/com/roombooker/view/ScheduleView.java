package com.roombooker.view;

import javax.swing.JPanel;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Dimension;
import javax.swing.JScrollPane;
import javax.swing.JViewport;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.LineBorder;

import com.roombooker.controller.ScheduleViewController;
import com.roombooker.model.Reservation;
import com.roombooker.model.RoomBookerModel;

import java.awt.Color;
import java.awt.BorderLayout;
import javax.swing.JScrollBar;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Component;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;

import java.awt.event.AdjustmentListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDateTime;
import java.util.Vector;

import javax.swing.ImageIcon;

public class ScheduleView extends JPanel {

	private final ScheduleViewController controller;
	private final JPanel headerView;
	private final JLabel titleLabel;
	private final JPanel rowHeaderView;
	private final JPanel colHeaderView;
	private final JPanel scheduleView;
	private final int rowHeight = 50;
	private final int colWidth = 75;
	private final int rowHeaderWidth = 125;
	private final Color headerFG = new Color(255, 255, 255);
	private final Color headerBG = new Color(65, 105, 225);
	private final Color cellBG = new Color(127, 255, 212);
	private final JScrollPane scrollPane;
	private ScheduleCell[][] scheduleViewModel;
	private ScheduleCell selectedCell = null;
	private LocalDateTime selectedDate;
	
	/**
	 * Create the panel.
	 */
	public ScheduleView(ScheduleViewController controller) {
		this.controller = controller;
		
		setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		setLayout(new BorderLayout(0, 0));
		
		// Set up the header
		headerView = new JPanel();
		headerView.setBackground(new Color(250, 240, 230));
		headerView.setLayout(new GridLayout(0, 1, 0, 0));
		titleLabel = new JLabel("");
		titleLabel.setIcon(new ImageIcon(ScheduleView.class.getResource("/images/schedule2.png")));
		titleLabel.setForeground(new Color(0, 0, 255));
		titleLabel.setMaximumSize(new Dimension(32767, 100));
		titleLabel.setMinimumSize(new Dimension(10, 100));
		titleLabel.setPreferredSize(new Dimension(32767, 100));
		titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
		titleLabel.setFont(new Font("Lucida Grande", Font.BOLD, 28));
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		headerView.add(titleLabel);
		add(headerView, BorderLayout.NORTH);
		
		// Set up the row headers
		rowHeaderView = new JPanel();
		Dimension d = new Dimension(rowHeaderWidth, 32767);
		rowHeaderView.setLayout(null);
		rowHeaderView.setSize(d);
		rowHeaderView.setPreferredSize(d);
		
		// temporary label
		JLabel label1 = new JLabel("Room 1");
		label1.setBorder(new EmptyBorder(0, 5, 0, 5));
		label1.setOpaque(true);
		label1.setForeground(new Color(255, 255, 255));
		label1.setBackground(new Color(65, 105, 225));
		label1.setBounds(1, rowHeight+1, colWidth-2, rowHeight-2);
		rowHeaderView.add(label1);

		paintRowHeaders();

		// Set up the col headers
		colHeaderView = new JPanel();
		colHeaderView.setLayout(null);
		d = new Dimension(
				colWidth * controller.getModel().getTimes().length, 
				rowHeight);
		colHeaderView.setSize(d);
		colHeaderView.setPreferredSize(d);
		
		paintColHeaders();

		// Setup the schedule panel
		scheduleView = new JPanel();
		scheduleView.setLayout(null);
		
		// temporary schedule cell
		JPanel panel = new JPanel();
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		panel.setBackground(new Color(127, 255, 212));
		panel.setBounds(1, rowHeight+1, colWidth-2, rowHeight-2);
		scheduleView.add(panel);
		
		initScheduleModel();
		
		// setup the scroll pane
		scrollPane = new JScrollPane();
		scrollPane.setViewportView(scheduleView);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setColumnHeaderView(colHeaderView);
		scrollPane.setRowHeaderView(rowHeaderView);
		JPanel corner = new JPanel();
		corner.setLayout(null);
		corner.setSize(rowHeaderWidth, rowHeight);
		JPanel cornerCell = new JPanel();
		cornerCell.setBackground(headerBG);
		cornerCell.setBounds(1, 1, rowHeaderWidth-2, rowHeight-2);
		corner.add(cornerCell);
		scrollPane.setCorner(ScrollPaneConstants.UPPER_LEFT_CORNER, corner);
		add(scrollPane, BorderLayout.CENTER);
	}
	
	public ScheduleViewController getController() {
		return controller;
	}
	
	private void paintRowHeaders() {
		rowHeaderView.removeAll();
		String[] rowHeaders = controller.getModel().getRoomNames();
		Dimension d = new Dimension( rowHeaderWidth, rowHeight * rowHeaders.length);
		rowHeaderView.setSize(d);
		rowHeaderView.setPreferredSize(d);
		for (int i = 0; i < rowHeaders.length; i++) {
			JLabel label = new JLabel(rowHeaders[i]);
			label.setBounds(1, (i*rowHeight) + 1, rowHeaderWidth-2, rowHeight-2);
			label.setOpaque(true);
			label.setForeground(headerFG);
			label.setBackground(headerBG);
			label.setBorder(new EmptyBorder(0, 5, 0, 5));
			rowHeaderView.add(label);
		}
	}
	
	private void paintColHeaders() {
		colHeaderView.removeAll();
		String[] colHeaders = controller.getModel().getTimes();
		for (int i = 0; i < colHeaders.length; i++) {
			JLabel label = new JLabel(colHeaders[i]);
			label.setBounds((i*colWidth) + 1, 1, colWidth-2, rowHeight-2);
			label.setOpaque(true);
			label.setForeground(headerFG);
			label.setBackground(headerBG);
			label.setBorder(new EmptyBorder(0, 2, 0, 2));
			colHeaderView.add(label);
		}
	}
	
	public JLabel getTitleLabel() {
		return titleLabel;
	}
	
	public void initScheduleModel() {
		scheduleView.removeAll();
		RoomBookerModel model = controller.getModel();
		int rows = model.getRoomNames().length;
		int cols = model.getTimes().length;
		
		Dimension d = new Dimension( colWidth * cols, rowHeight * rows);
		scheduleView.setSize(d);
		scheduleView.setPreferredSize(d);
		
		scheduleViewModel = new ScheduleCell[rows][cols];
		for (int r = 0; r < rows; r++) {
			for (int c = 0; c < cols; c++) {
				initCell(r,c);
			}
		}
		if (selectedDate != null) {
			Vector<Reservation> reservations = 
				model.getReservations(selectedDate);
			for (Reservation rsv : reservations) {
				int room = model.indexForRoom(rsv.getRoom());
				int time = model.indexFromTime(rsv.getTimeStart());
				int duration = rsv.getDuration() / 30;
				ScheduleCell cell = scheduleViewModel[room][time];
				for (int i = 1; i < duration; i++) {
					scheduleView.remove(scheduleViewModel[room][time+i]);
					scheduleViewModel[room][time+i] = cell;
				}
				cell.setBooked(rsv);
				cell.setSpan(duration);
			}
		}
	}
	
	public int getScheduleCols() {
		return scheduleViewModel[0].length;
	}
	
	public int getScheduleRows() {
		return scheduleViewModel.length;
	}
	
	public ScheduleCell getSelectedCell() {
		return selectedCell;
	}
	
	public void clearSelection() {
		if (selectedCell != null) {
			int r = selectedCell.getRow();
			int c = selectedCell.getCol();
			int s = selectedCell.getSpan();
			for (int i = c+1; i < c+s; i++) {
				initCell(r, i);
			}
			selectedCell.setSpan(1);
			selectCell(null);
		}
	}
	
	public void selectScheduleCell(ScheduleCell cell) {
		if (!cell.isSelected()) {
			int r = cell.getRow();
			int c = cell.getCol();
			if (c > 0 && getScheduleCell(r, c-1).isSelected()) {
				extendSelectionForward(cell);
			}
			else if (c < getScheduleCols()-1 
					&& getScheduleCell(r, c+1).isSelected()) {
				extendSelectionBack(cell);
			}
			else {
				clearSelection();
				selectCell(cell);
				revalidate();
				repaint();
			}
		}
	}

	
	public void selectCell(ScheduleCell cell) {
		if (selectedCell != null) {
			selectedCell.setSelected(false);
		}
		selectedCell = cell;
		if (selectedCell != null) {
			selectedCell.setSelected(true);
		}
		revalidate();
		repaint();
	}
	
	public ScheduleCell getScheduleCell(int r, int c) {
		return scheduleViewModel[r][c];
	}
	
	public void extendSelectionForward(ScheduleCell cell) {
		int r = cell.getRow();
		int c = cell.getCol();
		if (getScheduleCell(r, c-1).getSpan()<4) {
			scheduleView.remove(cell);
			scheduleView.revalidate();
			scheduleView.repaint();
			cell = scheduleViewModel[r][c-1];
			scheduleViewModel[r][c] = cell;
			cell.setSpan(cell.getSpan()+1);
		}
	}
	
	public void extendSelectionBack(ScheduleCell cell) {
		int r = cell.getRow();
		int c = cell.getCol();
		if (scheduleViewModel[r][c+1].getSpan()<4) {
			scheduleView.remove(cell);
			scheduleView.revalidate();
			scheduleView.repaint();
			cell = scheduleViewModel[r][c+1];
			scheduleViewModel[r][c] = cell;
			cell.setCol(c);
			cell.setSpan(cell.getSpan()+1);
		}
	}
	
	public void initCell(int r, int c) {
		ScheduleCell freeCell = new ScheduleCell(this, r, c, 1);
		scheduleViewModel[r][c] = freeCell;
		scheduleView.add(freeCell);
	}
	
	public void updateReservations() {
		paintRowHeaders();
		initScheduleModel();
		revalidate();
		repaint();
	}
	
	public void setSelectedDate(LocalDateTime date) {
		selectedDate = date;
		initScheduleModel();
		revalidate();
		repaint();
	}
}
