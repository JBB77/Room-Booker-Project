package com.roombooker.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.roombooker.RoomBookerApp;
import com.roombooker.controller.ManageRoomsViewController;

public class ManageRoomsView extends JDialog {

	private final ManageRoomsViewController controller;
	private final JPanel roomListPanel = new JPanel();
	private String[] roomNames;
	private final JList roomList;
	private final JPanel roomButtons;
	private final JButton cancelButton;
	private final JButton saveButton;
	private final JButton addRoomButton;
	private final JButton deleteRoomButton;
	private final JPanel editButtons;
	private final JButton editRoomButton;
	private final JLabel titleLabel;
	private final JTextField roomID;
	private final JTextField roomName;
	private final JLabel roomNameLabel;
	private final JLabel roomNumberLabel;
	private final JTextField capacity;
	private final JLabel capacityLabel;
	private boolean addMode = false;
	private boolean editMode = false;
	
	/**
	 * Create the dialog.
	 */
	public ManageRoomsView(ManageRoomsViewController controller) {
		this.controller = controller;
		
		setBounds(100, 100, 700, 450);
		resize();
		
		getContentPane().setLayout(new BorderLayout());
		{
			JPanel titlePanel = new JPanel();
			titlePanel.setBackground(Color.BLUE);
			getContentPane().add(titlePanel, BorderLayout.NORTH);
			titlePanel.setLayout(new GridLayout(0, 1, 0, 0));
			{
				JLabel title = new JLabel("Manage Rooms");
				title.setForeground(Color.WHITE);
				title.setHorizontalAlignment(SwingConstants.CENTER);
				title.setFont(new Font("Lucida Grande", Font.BOLD, 24));
				titlePanel.add(title);
			}
		}
		roomListPanel.setPreferredSize(new Dimension(250, 10));
		roomListPanel.setMinimumSize(new Dimension(250, 10));
		roomListPanel.setMaximumSize(new Dimension(250, 32767));
		roomListPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(roomListPanel, BorderLayout.WEST);
		roomListPanel.setLayout(new BorderLayout(0, 0));
		{
			roomList = new JList();
			roomList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			roomList.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
			roomList.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
			roomList.addListSelectionListener(new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent e) {
					controller.selectRoom(roomList.getSelectedIndex());
				}
			});
			updateRoomList();
			roomListPanel.add(roomList, BorderLayout.CENTER);
		}
		{
			roomButtons = new JPanel();
			roomButtons.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
			roomListPanel.add(roomButtons, BorderLayout.SOUTH);
			roomButtons.setLayout(new GridLayout(1, 0, 0, 0));
			{
				addRoomButton = new JButton("+");
				addRoomButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						enterAddMode();
					}
				});
				roomButtons.add(addRoomButton);
			}
			{
				deleteRoomButton = new JButton("-");
				deleteRoomButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						int index = roomList.getSelectedIndex();
						if (index >= 0) {
							int n = JOptionPane.showConfirmDialog(
								    null,
								    "Do you want to delete room " 
								    + roomNames[index] + "?",
								    "Confirm Deletion",
								    JOptionPane.YES_NO_OPTION);
							if (n == JOptionPane.YES_OPTION) {
								controller.deleteRoom(index);
								updateRoomList();
								if (roomNames.length > 0) {
									roomList.setSelectedIndex(0);
									controller.selectRoom(0);
								}
								else {
									roomList.clearSelection();
									controller.selectRoom(-1);
								}
							}
						}
					}
				});
				roomButtons.add(deleteRoomButton);
			}
			{
				editRoomButton = new JButton("Edit");
				editRoomButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if (roomNames.length > 0 && roomList.getSelectedIndex() >= 0) {
							enterEditMode();
						}
					}
				});
				roomButtons.add(editRoomButton);
			}
		}
		{
			JPanel roomFormPanel = new JPanel();
			roomFormPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
			getContentPane().add(roomFormPanel, BorderLayout.CENTER);
			roomFormPanel.setLayout(new BorderLayout(0, 0));
			{
				JPanel roomFields = new JPanel();
				roomFields.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
				roomFormPanel.add(roomFields, BorderLayout.CENTER);
				roomFields.setLayout(new GridLayout(10, 4, 0, 0));
				{
					titleLabel = new JLabel("Room Data");
					roomFields.add(titleLabel);
					titleLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
				}
				{
					roomNumberLabel = new JLabel("Room Number:");
					roomFields.add(roomNumberLabel);
				}
				{
					roomID = new JTextField();
					roomID.setEnabled(false);
					roomFields.add(roomID);
					roomID.setColumns(10);
				}
				roomNumberLabel.setLabelFor(roomID);
				{
					roomNameLabel = new JLabel("Room Name:");
					roomFields.add(roomNameLabel);
				}
				{
					roomName = new JTextField();
					roomName.setEnabled(false);
					roomFields.add(roomName);
					roomName.setColumns(10);
				}
				roomNameLabel.setLabelFor(roomName);
				{
					capacityLabel = new JLabel("Room Capacity:");
					roomFields.add(capacityLabel);
				}
				{
					capacity = new JTextField();
					capacity.setEnabled(false);
					roomFields.add(capacity);
					capacity.setColumns(10);
				}
				capacityLabel.setLabelFor(capacity);
			}
			{
				editButtons = new JPanel();
				editButtons.setVisible(false);
				editButtons.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
				roomFormPanel.add(editButtons, BorderLayout.SOUTH);
				{
					cancelButton = new JButton("Cancel");
					cancelButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							exitEditMode();
						}
					});
					cancelButton.setEnabled(false);
					editButtons.add(cancelButton);
				}
				{
					saveButton = new JButton("Save");
					saveButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							int index;
							String id = roomID.getText();
							String name = roomName.getText();
							int cap = Integer.valueOf(capacity.getText()).intValue();
							if (addMode) {
								index = controller.addRoom(id, name, cap);
							}
							else {
								index = roomList.getSelectedIndex();
								controller.updateRoom(index, id, name, cap);
							}
							exitEditMode();
							updateRoomList();
							roomList.setSelectedIndex(index);
							controller.selectRoom(index);
						}
					});
					saveButton.setEnabled(false);
					editButtons.add(saveButton);
				}
			}
		}
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setVisible(true);
	}

	public void resize() {
		if (RoomBookerApp.isRunning()) {
			Rectangle b1 = RoomBookerApp.getApp().getMainWindow().getBounds();
			Rectangle b2 = getBounds();
			b2.x = (b1.width - b2.width)/2;
			b2.y = (b1.height - b2.height)/2;
			setBounds(b2);
		}
	}
	
	public void setRoomFields(String roomNumber, String roomName, String capacity) {
		this.roomID.setText(roomNumber);
		this.roomName.setText(roomName);
		this.capacity.setText(capacity);
	}
	
	public void enterEditMode() {
		editMode = true;
		addRoomButton.setEnabled(false);
		editRoomButton.setEnabled(false);
		deleteRoomButton.setEnabled(false);
		roomList.setEnabled(false);
		roomID.setEnabled(false);
		roomName.setEnabled(true);
		capacity.setEnabled(true);
		cancelButton.setEnabled(true);
		saveButton.setEnabled(true);
		editButtons.setVisible(true);
		roomName.grabFocus();
	}
	
	public void exitEditMode() {
		addRoomButton.setEnabled(true);
		editRoomButton.setEnabled(true);
		deleteRoomButton.setEnabled(true);
		roomList.setEnabled(true);
		roomID.setEnabled(false);
		roomName.setEnabled(false);
		capacity.setEnabled(false);
		cancelButton.setEnabled(false);
		saveButton.setEnabled(false);
		editButtons.setVisible(false);
		editMode = false;
		addMode = false;
	}
	
	public void enterAddMode() {
		roomList.clearSelection();
		setRoomFields("", "", "");
		addMode = true;
		enterEditMode();
		roomID.setEnabled(true);
		roomID.grabFocus();
	}
	
	void updateRoomList() {
		roomNames = controller.getModel().getRoomNames();
		roomList.setModel(new AbstractListModel() {
			String[] values = roomNames;
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});

	}
}
