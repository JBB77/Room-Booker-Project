package com.roombooker.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JToolBar;
import javax.swing.border.EmptyBorder;

import com.roombooker.controller.MainViewController;
import com.roombooker.controller.ReservationViewController;
import com.roombooker.controller.ScheduleViewController;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainWindow extends JFrame {

	private final MainViewController controller;
	private final JPanel contentPane;
	private final ReservationView reservationView;
	private final ScheduleView scheduleView;

	/**
	 * Create the frame.
	 */
	public MainWindow(MainViewController controller) {
		this.controller = controller;
		contentPane = new JPanel();
		reservationView = ReservationViewController.createReservationView(this);
		scheduleView = ScheduleViewController.createScheduleView(this);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650, 500);
		
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		setVisible(true);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		JToolBar toolBar = new JToolBar();
		toolBar.setFloatable(false);
		contentPane.add(toolBar, BorderLayout.NORTH);

		JButton manageUsersButton = new JButton("Manage Users");
		manageUsersButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.manageUsers();
			}
		});
		manageUsersButton.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		manageUsersButton.setPreferredSize(new Dimension(180, 40));
		manageUsersButton.setMaximumSize(new Dimension(180, 40));
		manageUsersButton.setMinimumSize(new Dimension(180, 40));
		manageUsersButton.setIcon(new ImageIcon(ReservationView.class.getResource("/images/users_ico.png")));
		toolBar.add(manageUsersButton);
		
		JButton manageRoomsButton = new JButton("Manage Rooms");
		manageRoomsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.manageRooms();
			}
		});
		manageRoomsButton.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		manageRoomsButton.setPreferredSize(new Dimension(180, 40));
		manageRoomsButton.setMinimumSize(new Dimension(180, 40));
		manageRoomsButton.setMaximumSize(new Dimension(180, 40));
		manageRoomsButton.setIcon(new ImageIcon(ReservationView.class.getResource("/images/room_ico.png")));
		toolBar.add(manageRoomsButton);

		contentPane.add(reservationView, BorderLayout.WEST);
		
		contentPane.add(scheduleView, BorderLayout.CENTER);
		
		controller.onCalendarChange(reservationView.getCalendarView());
	}
	
	public MainViewController getController() {
		return controller;
	}
	
	public ReservationView getReservationView() {
		return reservationView;
	}
	
	public ScheduleView getScheduleView() {
		return scheduleView;
	}
}
