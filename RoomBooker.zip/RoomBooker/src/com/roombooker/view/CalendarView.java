package com.roombooker.view;

import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDateTime;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.roombooker.controller.CalendarViewController;
import com.roombooker.controller.ReservationViewController;

import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class CalendarView extends JPanel {
	private final CalendarViewController controller;
	private final JTable calendarTable;
	private final JComboBox selectMonth;
	private final JComboBox selectYear;
	private int firstYear;
	private int curMonth = -1;
	private int curYear = -1;
	private int curRow = -1;
	private int curCol = -1;
	private final String[][] calendarViewModel = {
		{ "","","","","","1","2" },
		{ "3","4","5","6","7","8","9" },
		{ "10","11","12","13","14","15","16" },
		{ "17","18","19","20","21","22","23" },
		{ "24","25","26","27","28","29","30" },
		{ "31","","","","","","" }
	};
	private final String[] yearModel = {"2016", "2017", "2018" };
	private final String[] calendarColumns = {
		"Sun", "Mon", "Tue", "Wed", "Thur", "Fri","Sat" 
	};
	private final String[] monthModel = {
		"January", "February", "March", "April", 
		"May", "June", "July", "August", "September", 
		"October", "November", "December"
	};
	private LocalDateTime calendarDate;

	/**
	 * Create the calendar view.
	 */
	public CalendarView(CalendarViewController controller) {
		this.controller = controller;
		selectMonth = new JComboBox();
		selectYear = new JComboBox();
		calendarTable = new JTable(calendarViewModel, calendarColumns) {  
			public boolean isCellEditable(int row, int column){  
				return false;  
			}  
		};
		
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setMaximumSize(new Dimension(32767, 165));
		setOpaque(false);
		
		Box calendarCtrl = Box.createHorizontalBox();
		calendarCtrl.setOpaque(true);
		calendarCtrl.setBackground(UIManager.getColor("Panel.background"));
		JButton prevMonth = new JButton("<");
		prevMonth.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				LocalDateTime d = calendarDate.minusMonths(1);
				d = LocalDateTime.of(d.getYear(), d.getMonth(), 1, 0, 0);
				if (d.isBefore(LocalDateTime.of(firstYear,1, 1, 0, 0))) {
					return;
				}
				setDate(d);
			}
		});
		prevMonth.setBorder(null);
		prevMonth.setPreferredSize(new Dimension(25, 30));
		calendarCtrl.add(prevMonth);
		selectMonth.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					int m = selectMonth.getSelectedIndex();
					if (m != curMonth) {
						setDate(LocalDateTime.of(getYear(), m+1, 1, 0, 0));
					}
			    }
			}
		});
		selectMonth.setModel(new DefaultComboBoxModel(monthModel));
		calendarCtrl.add(selectMonth);
		
		selectYear.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					int y = selectYear.getSelectedIndex();
					if (y != curYear) {
						setDate(LocalDateTime.of(firstYear + y, getMonth(), 1, 0, 0));
					}
			    }
			}
		});
		selectYear.setModel(new DefaultComboBoxModel(yearModel));
		calendarCtrl.add(selectYear);
		JButton nextMonth = new JButton(">");
		nextMonth.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				LocalDateTime d = calendarDate.plusMonths(1);
				d = LocalDateTime.of(d.getYear(), d.getMonth(), 1, 0, 0);
				if (d.isAfter(LocalDateTime.of(firstYear+2,12, 31, 23, 59))) {
					return;
				}
				setDate(d);
			}
		});
		nextMonth.setBorder(null);
		nextMonth.setPreferredSize(new Dimension(25, 30));
		calendarCtrl.add(nextMonth);
		add(calendarCtrl);

		calendarTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		calendarTable.setOpaque(false);
		calendarTable.setRowHeight(20);
		calendarTable.setCellSelectionEnabled(true);
		calendarTable.getTableHeader().setReorderingAllowed(false);
		calendarTable.getTableHeader().setResizingAllowed(false);
		calendarTable.getSelectionModel().addListSelectionListener(
			new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent e) {
					if (e.getValueIsAdjusting()) {
						return;
					}
					calendarChangeEvent();
				}
			});
		calendarTable.getColumnModel().getSelectionModel().addListSelectionListener(
			new ListSelectionListener() {
				public void valueChanged(ListSelectionEvent e) {
					if (e.getValueIsAdjusting()) {
						return;
					}
					calendarChangeEvent();
				}
			});
		add(calendarTable.getTableHeader());	
		add(calendarTable);
		
		// set up array of years- you can select
		// previous, current or next year
		LocalDateTime now = LocalDateTime.now();
		firstYear = now.getYear()-1;
		yearModel[0] = String.valueOf(firstYear);
		yearModel[1] = String.valueOf(firstYear+1);
		yearModel[2] = String.valueOf(firstYear+2);
		setDate(now);
	}
	
	public CalendarViewController getController() {
		return controller;
	}
	
	private void setDate(LocalDateTime date) {
		calendarDate = date;
		initCalendar();
		curMonth = getMonth()-1;
		selectMonth.setSelectedIndex(curMonth);
		curYear = getYear() - firstYear;
		selectYear.setSelectedIndex(curYear);
		int days = calendarViewModel.length * 7;
		for (int d = 0; d < days; d++) {
			if (calendarViewModel[d/7][d%7].equals(String.valueOf(getDay()))) {
				calendarTable.changeSelection(d/7, d%7, false, false);
				curRow = d/7;
				curCol = d%7;
				break;
			}
		}
		revalidate();
		repaint();
		controller.onCalendarChange();
	}
	
	private void calendarChangeEvent() {
		int rowIndex = calendarTable.getSelectedRow();
		int colIndex = calendarTable.getSelectedColumn();
		if (rowIndex < 0 || colIndex < 0) {
			return;
		}
		if (rowIndex != curRow || colIndex != curCol) {
			if (calendarViewModel[rowIndex][colIndex].equals("")) {
				calendarTable.changeSelection(curRow, curCol, false, false);
			}
			else {
				int day = Integer.valueOf(
						calendarViewModel[rowIndex][colIndex]).intValue();
				LocalDateTime d = LocalDateTime.of(getYear(), getMonth(), day, 0, 0);
				setDate(d);
			}
		}
	}
	
	private void initCalendar() {		
		int dayPos = 0;
		int day1 = getFirstDayOfWeek();
		while (dayPos < day1) {
			calendarViewModel[dayPos/7][dayPos%7] = "";
			dayPos++;
		}
		int days = getDaysInMonth();
		for (int day = 1; day <= days; day++) {
			calendarViewModel[dayPos/7][dayPos%7] = String.valueOf(day);
			dayPos++;
		}
		days = calendarViewModel.length * 7;
		while (dayPos < days) {
			calendarViewModel[dayPos/7][dayPos%7] = "";
			dayPos++;
		}
	}
	
	public int getMonth() {
		return calendarDate.getMonthValue();
	}
	
	public int getDay() {
		return calendarDate.getDayOfMonth();
	}
	
	public int getYear() {
		return calendarDate.getYear();
	}
	
	// Current selected day of week
	// returns 0..6 for Sunday..Saturday
	public int getDayOfWeek() {
		int dow = calendarDate.getDayOfWeek().getValue() + 1;
		if (dow == 8) {
			dow = 1;
		}
		return dow-1;
	}
	
	public int getDaysInMonth() {
		LocalDateTime d = LocalDateTime.of(getYear(), calendarDate.getMonth(), 1, 0, 0);
		d = d.plusMonths(1);
		d = LocalDateTime.of(d.getYear(), d.getMonth(), 1, 0, 0).minusDays(1);
		return d.getDayOfMonth();
	}
	
	// Day of week of first day in month
	// returns 0..6 for Sunday..Saturday
	public int getFirstDayOfWeek() {
		LocalDateTime d = LocalDateTime.of(getYear(), calendarDate.getMonth(), 1, 0, 0);
		int dow = d.getDayOfWeek().getValue() + 1;
		if (dow == 8) {
			dow = 1;
		}
		return dow-1;
	}
	
	public String getMonthName() {
		return monthModel[getMonth()-1];
	}
	
	public LocalDateTime getDate() {
		return calendarDate;
	}

}
