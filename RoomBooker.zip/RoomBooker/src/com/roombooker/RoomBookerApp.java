package com.roombooker;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.roombooker.controller.MainViewController;
import com.roombooker.model.RoomBookerModel;
import com.roombooker.view.MainWindow;

public class RoomBookerApp {

	private static RoomBookerApp _app;
	private final RoomBookerModel _model;
	private final MainWindow _mainWindow;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RoomBookerApp.getApp();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public static boolean isRunning() {
		return _app != null;
	}
	
	private RoomBookerApp() {
		//private  constructor
		_app = this;
		_model = RoomBookerModel.getRoomBookerModel();
		_mainWindow = MainViewController.createMainWindow();
	}
	
	public static RoomBookerApp getApp() {
		if (_app == null) {
			return new RoomBookerApp();
		}
		else {
			return _app;
		}
	}
	
	public RoomBookerModel getModel() {
		return _model;
	}
	
	public MainWindow getMainWindow() {
		return _mainWindow;
	}
}
