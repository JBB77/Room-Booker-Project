package com.roombooker.controller;

import com.roombooker.RoomBookerApp;
import com.roombooker.model.ModelListener;
import com.roombooker.model.RoomBookerModel;
import com.roombooker.view.CalendarView;
import com.roombooker.view.MainWindow;
import com.roombooker.view.ReservationView;

public class CalendarViewController implements ModelListener {
	
	private final ReservationView reservationView;
	private final RoomBookerModel model;
	private CalendarView view;
	private boolean inEvent = false;
	
	public static CalendarView createCalendarView(ReservationView reservationView) {
		CalendarViewController ctrlr = new CalendarViewController(reservationView);
		CalendarView view = new CalendarView(ctrlr);
		ctrlr.setView(view);
		return view;
	}

	private CalendarViewController(ReservationView reservationView) {
		this.reservationView = reservationView;
		model = RoomBookerApp.getApp().getModel();
		model.registerModelListener(this);
	}
	
	private void setView(CalendarView view) {
		this.view = view;
	}
	
	public CalendarView getView() {
		return view;
	}
	
	public RoomBookerModel getModel() {
		return model;
	}
	
	public void onCalendarChange() {
		if (!inEvent) {
			inEvent = true;
			reservationView.getController().onCalendarChange(view);
			inEvent = false;
		}
	}

	@Override
	public void notifyModelChange() {
	}
}
