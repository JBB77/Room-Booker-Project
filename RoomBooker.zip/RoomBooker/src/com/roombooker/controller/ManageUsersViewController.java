package com.roombooker.controller;

import java.util.Vector;

import com.roombooker.RoomBookerApp;
import com.roombooker.model.ModelListener;
import com.roombooker.model.RoomBookerModel;
import com.roombooker.model.Student;
import com.roombooker.model.Teacher;
import com.roombooker.model.User;
import com.roombooker.view.ManageUsersView;

public class ManageUsersViewController implements ModelListener {
	
	private final RoomBookerModel model;
	private ManageUsersView view;
	
	public static ManageUsersView createManageUsersView() {
		ManageUsersViewController ctrlr = new ManageUsersViewController();
		ManageUsersView view = new ManageUsersView(ctrlr);
		ctrlr.setView(view);
		return view;
	}

	private ManageUsersViewController() {
		model = RoomBookerApp.getApp().getModel();
	}
	
	private void setView(ManageUsersView view) {
		this.view = view;
	}
	
	public ManageUsersView getView() {
		return view;
	}
	
	public RoomBookerModel getModel() {
		return model;
	}
	
	public void selectUser(int index) {
		if (index > -1) {
			User user = model.getUsers().get(index);
			if (user instanceof Student) {
				view.setUserFields(
						user.getUserID(), 
						user.getUserName(), 
						((Student)user).getStudentID(), true);
			}
			else {
				view.setUserFields(
						user.getUserID(), 
						user.getUserName(), 
						((Teacher)user).getDepartment(), false);
			}
		}
		else {
			view.setUserFields("", "", "", true);
		}
	}
	
	public int addUser(String userID, String userName, String deptId, boolean isStudent) {
		model.addUser(userID, userName, deptId, isStudent);
		return findUserIndex(userID);
	}
	
	private int findUserIndex(String userID) {
		Vector<User> users = model.getUsers();
		int i = 0;
		for (User user : users) {
			if (user.getUserID().equals(userID)) {
				return i;
			}
			i++;
		}
		return -1;
	}
	
	public void updateUser(int index, String userName, String deptId) {
		User user = model.getUsers().get(index);
		user.setUserName(userName);
		if (user instanceof Student) {
			((Student)user).setStudentID(deptId);
		}
		else {
			((Teacher)user).setDepartment(deptId);
		}
		model.updateUser(user);
	}
	
	public void deleteUser(int index) {
		User user = model.getUsers().get(index);
		model.deleteUser(user);
	}
	
	@Override
	public void notifyModelChange() {
	}
}
