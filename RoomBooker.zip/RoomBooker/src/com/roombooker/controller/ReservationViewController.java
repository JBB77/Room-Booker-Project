package com.roombooker.controller;

import java.time.LocalDateTime;

import javax.swing.JOptionPane;

import com.roombooker.RoomBookerApp;
import com.roombooker.model.ModelListener;
import com.roombooker.model.Reservation;
import com.roombooker.model.Room;
import com.roombooker.model.RoomBookerModel;
import com.roombooker.model.User;
import com.roombooker.view.CalendarView;
import com.roombooker.view.MainWindow;
import com.roombooker.view.ReservationView;

public class ReservationViewController implements ModelListener {
	
	private final MainWindow mainView;
	private final RoomBookerModel model;
	private ReservationView view;
	private boolean inEvent = false;
	
	public static ReservationView createReservationView(MainWindow mainView) {
		ReservationViewController ctrlr = new ReservationViewController(mainView);
		ReservationView view = new ReservationView(ctrlr);
		ctrlr.setView(view);
		return view;
	}

	private ReservationViewController(MainWindow mainView) {
		this.mainView = mainView;
		model = RoomBookerApp.getApp().getModel();
		model.registerModelListener(this);
	}
	
	private void setView(ReservationView view) {
		this.view = view;
	}
	
	public ReservationView getView() {
		return view;
	}
	
	public RoomBookerModel getModel() {
		return model;
	}
	
	protected boolean onCalendarChange(CalendarView calendar) {
		if (!inEvent) {
			if (view != null) {
				inEvent = true;
				int room = view.getSelectRoomControl().getSelectedIndex();
				int time = view.getSelectTimeControl().getSelectedIndex();
				int duration = view.getSelectDurationControl().getSelectedIndex();
				mainView.getController().onCalendarChange(calendar);
				inEvent = false;
				onScheduleChange(room, time, duration);
			}
		}
		return true;
	}
	
	public void setScheduleRoomTime(int room, int time, int duration) {
		if (!inEvent) {
			inEvent = true;
			view.getSelectRoomControl().setSelectedIndex(room+1);
			view.getSelectTimeControl().setSelectedIndex(time+1);
			view.getSelectDurationControl().setSelectedIndex(duration+1);
			inEvent = false;
		}
	}
	
	public void onScheduleChange(int room, int time, int duration) {
		if (room > 0 && time > 0 && duration > 0) {
			if (!inEvent) {
				inEvent = true;
				mainView.getController().onRoomTimeChange(room-1, time-1, duration);
				inEvent = false;
			}
		}
	}
	
	public void confirmReservation(int userIndex, int people, CalendarView calendar,
			int roomIndex, int timeIndex, int duration) {
		if (userIndex <= 0) {
			JOptionPane.showMessageDialog(null, 
					"Please select a user for this reservation.");
			return;
		}
		if (people <= 0) {
			JOptionPane.showMessageDialog(null, 
					"You must specify the number of people in your group.");
			return;
		}
		if (roomIndex <= 0) {
			JOptionPane.showMessageDialog(null, 
					"Please select a room to reserve.");
			return;
		}
		if (timeIndex <= 0) {
			JOptionPane.showMessageDialog(null, 
					"Please select the reservation time.");
			return;
		}
		if (duration <= 0) {
			JOptionPane.showMessageDialog(null, 
					"Please select the meeting duration.");
			return;
		}
		duration = duration * 30;
		
		User user = model.getUsers().get(userIndex-1);
		Room room = model.getRooms().get(roomIndex-1);
		
		if (people > room.getCapacity()) {
			JOptionPane.showMessageDialog(null, 
					"This room is too small for your group.\n(Capacity " 
					+ room.getCapacity() + ")");
			return;
		}
		
		if (Reservation.totalReservedForDay(user.getUserID(), calendar.getDate()) 
				+ duration > 120) {
			JOptionPane.showMessageDialog(null, 
					"You may reserve a maximum of 2 hours in a day.\n");
			return;
		}
		
		int timeStart = model.timeFromIndex(timeIndex-1);
		int timeEnd = timeStart + duration;
		
		Reservation rsv = Reservation.createNewReservation(
			user, room, people, calendar.getDate(), timeStart, timeEnd);
		
		if (rsv.isRoomAlreadyBooked()) {
			JOptionPane.showMessageDialog(null, "This room is already booked at this time.");
			return;
		}
		
		if (rsv.isUserAlreadyBooked()) {
			JOptionPane.showMessageDialog(null, "You already have a reservation at this time.");
			return;
		}
		
		model.saveReservation(rsv);

		view.initialize();
		JOptionPane.showMessageDialog(null, "Your room reservation is confirmed.");
		inEvent = false;
	}

	@Override
	public void notifyModelChange() {
		view.updateLists();
	}
}
