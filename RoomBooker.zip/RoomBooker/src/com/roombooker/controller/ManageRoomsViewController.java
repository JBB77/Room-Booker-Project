package com.roombooker.controller;

import java.util.Vector;

import com.roombooker.RoomBookerApp;
import com.roombooker.model.ModelListener;
import com.roombooker.model.Room;
import com.roombooker.model.RoomBookerModel;
import com.roombooker.view.ManageRoomsView;

public class ManageRoomsViewController implements ModelListener {
	
	private final RoomBookerModel model;
	private ManageRoomsView view;
	
	public static ManageRoomsView createManageRoomsView() {
		ManageRoomsViewController ctrlr = new ManageRoomsViewController();
		ManageRoomsView view = new ManageRoomsView(ctrlr);
		ctrlr.setView(view);
		return view;
	}

	private ManageRoomsViewController() {
		model = RoomBookerApp.getApp().getModel();
	}
	
	private void setView(ManageRoomsView view) {
		this.view = view;
	}
	
	public ManageRoomsView getView() {
		return view;
	}
	
	public RoomBookerModel getModel() {
		return model;
	}
	
	public void selectRoom(int index) {
		if (index > -1) {
			Room room = model.getRooms().get(index);
			view.setRoomFields(
				room.getRoomID(), 
				room.getRoomName(), 
				String.valueOf(room.getCapacity()));
		}
		else {
			view.setRoomFields("","","");
		}
	}
	
	public int addRoom(String roomID, String roomName, int capacity) {
		model.addRoom(roomID, roomName, capacity);
		return findRoomIndex(roomID);
	}

	private int findRoomIndex(String roomID) {
		Vector<Room> rooms = model.getRooms();
		int i = 0;
		for (Room room : rooms) {
			if (room.getRoomID().equals(roomID)) {
				return i;
			}
			i++;
		}
		return -1;
	}

	public void updateRoom(int index, String roomID, String roomName, int capacity) {
		Room room = model.getRooms().get(index);
		room.setRoomName(roomName);
		room.setCapacity(capacity);
		model.updateRoom(room);
	}
	
	public void deleteRoom(int index) {
		Room room = model.getRooms().get(index);
		model.deleteRoom(room);
	}
	
	@Override
	public void notifyModelChange() {
	}
}
