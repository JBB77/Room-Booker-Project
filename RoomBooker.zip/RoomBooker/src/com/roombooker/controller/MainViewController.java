package com.roombooker.controller;

import java.time.LocalDateTime;

import com.roombooker.RoomBookerApp;
import com.roombooker.model.ModelListener;
import com.roombooker.model.RoomBookerModel;
import com.roombooker.view.CalendarView;
import com.roombooker.view.MainWindow;
import com.roombooker.view.ManageRoomsView;
import com.roombooker.view.ManageUsersView;
import com.roombooker.view.ReservationView;

public class MainViewController implements ModelListener {
	
	private final RoomBookerModel model;
	private MainWindow view;
	private boolean inEvent = false;
	
	public static MainWindow createMainWindow() {
		MainViewController ctrlr = new MainViewController();
		MainWindow view = new MainWindow(ctrlr);
		ctrlr.setView(view);
		return view;
	}

	private MainViewController() {
		model = RoomBookerApp.getApp().getModel();
		model.registerModelListener(this);
	}
	
	private void setView(MainWindow view) {
		this.view = view;
		view.getScheduleView().getController()
			.setScheduleDate(view.getReservationView().getCalendarView());
	}
	
	public MainWindow getView() {
		return view;
	}
	
	public RoomBookerModel getModel() {
		return model;
	}
	
	public void onCalendarChange(CalendarView calendar) {
		if (view != null) {
			if (!inEvent) {
				inEvent = true;
				view.getScheduleView().getController().setScheduleDate(calendar);
				inEvent = false;
			}
		}
	}
	
	public void onRoomTimeChange(int room, int time, int duration) {
		if (view != null) {
			if (!inEvent) {
				inEvent = true;
				view.getScheduleView().getController().setSchedule(room, time, duration);
				inEvent = false;
			}
		}
	}
	
	public void onScheduleChange(int room, int time, int duration) {
		if (view != null) {
			if (!inEvent) {
				inEvent = true;
				view.getReservationView().getController().setScheduleRoomTime(room, time, duration);
				inEvent = false;
			}
		}
	}
	
	public void manageRooms() {
		ManageRoomsView mrvc = 
				ManageRoomsViewController.createManageRoomsView();
	}
	
	public void manageUsers() {
		ManageUsersView muvc = 
				ManageUsersViewController.createManageUsersView();
	}

	@Override
	public void notifyModelChange() {
	}
}
