package com.roombooker.controller;

import java.time.LocalDateTime;

import com.roombooker.RoomBookerApp;
import com.roombooker.model.ModelListener;
import com.roombooker.model.RoomBookerModel;
import com.roombooker.view.CalendarView;
import com.roombooker.view.MainWindow;
import com.roombooker.view.ReservationView;
import com.roombooker.view.ScheduleView;
import com.roombooker.view.ScheduleCell;

public class ScheduleViewController implements ModelListener {
	
	private final MainWindow mainView;
	private final RoomBookerModel model;
	private ScheduleView view;
	boolean inEvent = false;
	
	public static ScheduleView createScheduleView(MainWindow mainView) {
		ScheduleViewController ctrlr = new ScheduleViewController(mainView);
		ScheduleView view = new ScheduleView(ctrlr);
		ctrlr.setView(view);
		return view;
	}

	private ScheduleViewController(MainWindow mainView) {
		this.mainView = mainView;
		model = RoomBookerApp.getApp().getModel();
		model.registerModelListener(this);
	}
	
	private void setView(ScheduleView view) {
		this.view = view;
	}
	
	public ScheduleView getView() {
		return view;
	}
	
	public RoomBookerModel getModel() {
		return model;
	}
	
	public void setScheduleDate(CalendarView calendar) {
		if (!inEvent) {
			inEvent = true;
			view.clearSelection();
			String titleString = "    Room Schedule for "
					+ calendar.getMonthName() + " "
					+ String.valueOf(calendar.getDay()) + ", "
					+ String.valueOf(calendar.getYear());
			view.getTitleLabel().setText(titleString);
			view.setSelectedDate(calendar.getDate());
			inEvent = false;
		}
	}
	
	public void onRoomTimeChange(int room, int time, int duration) {
		if (!inEvent) {
			inEvent = true;
			mainView.getController().onScheduleChange(room, time, duration);
			inEvent = false;
		}
	}

	public void clickScheduleCell(ScheduleCell cell) {
		if (inEvent) {
			return;
		}
		inEvent = true;
		if (!cell.isBooked()) {
			if (cell.isSelected()) {
				view.clearSelection();
				mainView.getController().onScheduleChange(-1, -1, -1);
			}
			else {
				view.selectScheduleCell(cell);
				ScheduleCell selectedCell = view.getSelectedCell();
				if (selectedCell != null) {
					mainView.getController().onScheduleChange(
							selectedCell.getRow(), 
							selectedCell.getCol(), 
							selectedCell.getSpan()-1);
				}
			}
		}
		inEvent = false;
	}
		
	public void setSchedule(int room, int time, int duration) {
		if (!inEvent) {
			inEvent = true;
			view.clearSelection();
			for (int i = 0; i < duration; i++) {
				if (view.getScheduleCell(room, time+i).isBooked()) {
					inEvent = false;
					return;
				}
			}
			for (int c = time; c < time + duration; c++) {
				if (c < view.getScheduleCols()) {
					view.selectScheduleCell(view.getScheduleCell(room, c));
				}
				else {
					// todo reset span at end of day
				}
			}
			inEvent = false;
		}
	}
	
	@Override
	public void notifyModelChange() {
		view.updateReservations();
	}
}
