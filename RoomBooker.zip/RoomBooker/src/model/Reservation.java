package model;
import java.util.Date;

public class Reservation {
	private final String reservationID;
	private final User user;
	private final Room room;
	private final Date reserveFrom;
	private final Date reserveTo;
	
	public Reservation(String reservationID, User user, Room room, Date reserveFrom, Date reserveTo) {
		this.reservationID = reservationID;
		this.user = user;
		this.room = room;
		this.reserveFrom = reserveFrom;
		this.reserveTo = reserveTo;
	}
	
	public User getUser() {
		return user;
	}
	public Room getRoom() {
		return room;
	}
	public Date getReserveFrom() {
		return reserveFrom;
	}
	public Date getReserveTo() {
		return reserveTo;
	}
	
	// Factor method to load Room instances from database
	static Reservation loadReservation(final String reservationID) {
		// Lookup reservationID in the database
		// copy fields
		// Create User instance
		// (this is temporary until database is put here)
		Student s = new Student("todo", "todo", "todo");
		Room r = new Room("todo", "todo", 0);
		return new Reservation(reservationID, s, r, null, null);
	}
	
	public void update() {
		// Todo: update the database with new or updated data
	}
	
	public void delete() {
		// Todo: delete this student from the database
	}

}
