package model;

public class Teacher extends User {
	private String department;
	
	public Teacher(String userID, String userName, String department) {
		super(userID, userName);
		this.department = department;
	}
	
	public String getDepartment() {
		return department;
	}
	
	public void setDepartment(String department) {
		this.department = department;
	}
	
	// Factor method to load Room instances from database
	static User loadTeacher(final String userID) {
		// Lookup userID in the database
		// copy fields
		// Create User instance
		// (this is temporary until database is put here)
		return new Teacher(userID, "todo", "todo");
	}
	
	public void update() {
		// Todo: update the database with new or updated data
	}
	
	public void delete() {
		// Todo: delete this teacher from the database
	}
}
