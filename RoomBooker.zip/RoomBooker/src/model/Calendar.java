package model;
import java.util.Vector;

public class Calendar {
	private Vector<Room> rooms;
	private Vector<User> users;
	private Vector<Reservation> reservations;
	
	// Todo... what methods do we need?
	// We'll have lookup methods, book methods etc
	// that can be used by the GUI
	
}
