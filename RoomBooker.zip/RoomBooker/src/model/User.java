package model;

public abstract class User {
	private final String userID;
	private String userName;
	
	public User(String userID, String userName) {
		this.userID = userID;
		this.userName = userName;
	}
	
	public String getUserID() {
		return userID;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	abstract public void update();
	abstract public void delete();
}
