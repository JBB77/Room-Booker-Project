package model;

public class Student extends User {
	
	private String studentID;
	
	public Student(String userID, String userName, String studentID) {
		super(userID, userName);
		this.studentID = studentID;
	}
	
	public String getStudentID() {
		return studentID;
	}
	
	public void setStudentID(String studentID) {
		this.studentID = studentID;
	}
	
	// Factor method to load Room instances from database
	static Student loadStudent(final String userID) {
		// Lookup userID in the database
		// copy fields
		// Create User instance
		// (this is temporary until database is put here)
		return new Student(userID, "todo", "todo");
	}
	
	public void update() {
		// Todo: update the database with new or updated data
	}
	
	public void delete() {
		// Todo: delete this student from the database
	}
}
