package model;

public class Room {
	
	private final String roomNumber;
	private String roomName;
	private int maxPeople;
	
	public Room(String roomNumber, String roomName, int maxPeople) {
		this.roomNumber = roomNumber;
		this.roomName = roomName;
		this.maxPeople = maxPeople;
	}
	
	public String getRoomNumber() {
		return roomNumber;
	}
	
	public String getRoomName() {
		return roomName;
	}
	
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	
	public int getMaxPeople() {
		return maxPeople;
	}
	
	public void setMaxPeople(int maxPeople) {
		this.maxPeople = maxPeople;
	}
	
	
	// Factor method to load Room instances from database
	static Room loadRoom(final String roomNumber) {
		// Lookup room # in the database
		// copy fields
		// Create Room instance
		// (this is temporary until database is put here)
		return new Room(roomNumber, "todo", 0);
	}
	
	void updateRoom() {
		// Todo: update the database with new or updated data
	}
	
	void deleteRoom() {
		// Todo: delete this room from the database
	}
}
