package view;

public class ScheduleView {

}
