package view;

public class RoomView {

}
